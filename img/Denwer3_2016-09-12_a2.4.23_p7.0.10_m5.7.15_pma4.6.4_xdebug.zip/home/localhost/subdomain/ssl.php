Текущий порт сервера: <?=$_SERVER['SERVER_PORT']?><br>
SSL сейчас активен: <?=$_SERVER['SERVER_PORT'] == 443? 'да' : 'нет'?><br>
