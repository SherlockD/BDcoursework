#!/usr/local/miniperl/miniperl
print "Content-Type: text/html\n\n";
print "<html><br><br><br><br><h2 align=center>Этот текст сгенерирован файлом /home/localhost/cgi/test.pl, расположенным в CGI-директории виртуального хоста localhost.";
