#!/usr/bin/php5
<h1>Проверка CGI-версии PHP</h1>
<?
phpinfo();
?>
