#!/usr/local/miniperl/miniperl
print "Content-Type: text/html\n\n";
print "<html><br><br><br><br><h2 align=center>Этот текст сгенерирован файлом <tt>/home/localhost/cgi-bin/test.pl</tt>, расположенным в CGI-директории виртуального хоста localhost.";
