#!/usr/local/miniperl/miniperl
print "Content-Type: text/html\n\n";
print "<html><br><br><br><br><h2 align=center>Этот текст сгенерирован файлом <tt>$0</tt>, расположенным в общей для всех хостов CGI-директории.";
