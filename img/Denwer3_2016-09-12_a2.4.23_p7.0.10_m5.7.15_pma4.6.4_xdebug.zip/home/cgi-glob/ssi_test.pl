#!/usr/local/miniperl/miniperl
print "Content-Type: text/html\n\n";
print "Этот текст сгенерирован файлом <tt>$0</tt>.";
